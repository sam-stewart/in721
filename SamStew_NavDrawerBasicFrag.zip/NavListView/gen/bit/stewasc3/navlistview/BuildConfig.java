/** Automatically generated file. DO NOT MODIFY */
package bit.stewasc3.navlistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}