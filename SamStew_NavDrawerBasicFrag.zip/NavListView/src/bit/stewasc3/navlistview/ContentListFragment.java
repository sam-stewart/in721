package bit.stewasc3.navlistview;

import android.support.v4.app.ListFragment;

public class ContentListFragment extends ListFragment
{

}
