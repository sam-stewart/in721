/** Automatically generated file. DO NOT MODIFY */
package bit.stewasc3.complexcontrols;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}